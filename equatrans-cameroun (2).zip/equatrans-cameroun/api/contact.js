export default async function handler(req, res) {
    // Only allow POST requests from your form
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    const { name, company, phone, subject, msg } = req.body;

    // Access your secret API key safely from Vercel Environment Variables
    const apiKey = process.env.MY_API_KEY;

    try {
        // Example: Call your external API here using `apiKey`
        // const externalRes = await fetch('https://api.example.com/send', { ... });

        return res.status(200).json({ 
            success: true, 
            message: `Demande reçue pour ${company}` 
        });
    } catch (error) {
        return res.status(500).json({ error: 'Erreur serveur lors de l’envoi' });
    }
}